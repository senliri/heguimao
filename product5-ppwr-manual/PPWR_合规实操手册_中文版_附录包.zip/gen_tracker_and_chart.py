# -*- coding: utf-8 -*-
"""
Generate PPWR Progress Tracker (Excel) and Flowchart (PNG)
Uses openpyxl and PIL - no external dependencies beyond Pillow + openpyxl
"""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont

base_dir = r'D:\qclaw\workspace-AI工程师\product5-ppwr-manual\bonus'

# ============================================================
# 1. Excel Progress Tracker
# ============================================================
wb = Workbook()

header_font = Font(bold=True, color='FFFFFF', size=11)
header_fill = PatternFill(start_color='1A365D', end_color='1A365D', fill_type='solid')
status_done = PatternFill(start_color='C6F6D5', end_color='C6F6D5', fill_type='solid')
status_progress = PatternFill(start_color='FEFCBF', end_color='FEFCBF', fill_type='solid')
status_pending = PatternFill(start_color='FFF5F5', end_color='FFF5F5', fill_type='solid')
thin_border = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)

def style_header(ws, row, cols):
    for c in range(1, cols+1):
        cell = ws.cell(row=row, column=c)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = thin_border

def style_data_cell(ws, row, col, status=None):
    cell = ws.cell(row=row, column=col)
    cell.border = thin_border
    cell.alignment = Alignment(vertical='center', wrap_text=True)
    cell.font = Font(size=10)
    if status == 'done':
        cell.fill = status_done
    elif status == 'progress':
        cell.fill = status_progress
    elif status == 'pending':
        cell.fill = status_pending

# --- Sheet 1: EPR Registration Progress ---
ws1 = wb.active
ws1.title = "EPR Registration"
headers1 = ['No.', 'Country', 'EPR Reg. No.', 'PRO/Service Provider', 'Registration Date',
            'Next Deadline', 'Platform Status', 'Notes']
for c, h in enumerate(headers1, 1):
    ws1.cell(row=1, column=c, value=h)
style_header(ws1, 1, len(headers1))

countries = [
    ('Germany', '', 'Der Grune Punkt / Landbell', '', '', '', ''),
    ('France', '', 'Citeo / Eco-Emballages', '', '', '', ''),
    ('Italy', '', 'MAEC / National Registry', '', '', '', ''),
    ('Spain', '', 'Regional PROs', '', '', '', ''),
    ('Belgium', '', 'Packaging Registration System', '', '', '', ''),
    ('Netherlands', '', 'NAP System', '', '', '', ''),
    ('Ireland', '', 'EPA', '', '', '', ''),
    ('Poland', '', 'Producer Registry', '', '', '', ''),
    ('Sweden', '', 'Producer Responsibility Org', '', '', '', ''),
]
for i, (country, reg_no, pro, reg_date, next_dl, plat_st, note) in enumerate(countries, 2):
    ws1.cell(row=i, column=1, value=i-1)
    ws1.cell(row=i, column=2, value=country)
    ws1.cell(row=i, column=3, value=reg_no)
    ws1.cell(row=i, column=4, value=pro)
    ws1.cell(row=i, column=5, value=reg_date)
    ws1.cell(row=i, column=6, value=next_dl)
    ws1.cell(row=i, column=7, value=plat_st)
    ws1.cell(row=i, column=8, value=note)
    for c in range(1, len(headers1)+1):
        style_data_cell(ws1, i, c)

widths1 = [6, 16, 22, 25, 14, 16, 16, 25]
for w, col in zip(widths1, range(1, len(headers1)+1)):
    ws1.column_dimensions[get_column_letter(col)].width = w

# --- Sheet 2: Platform Submission Status ---
ws2 = wb.create_sheet("Platform Status")
headers2 = ['Platform', 'Region', 'Reg No. Submitted', 'Submit Date', 'Review Result', 'Rejection Reason', 'Notes']
for c, h in enumerate(headers2, 1):
    ws2.cell(row=1, column=c, value=h)
style_header(ws2, 1, len(headers2))

platforms = [
    ('Amazon', 'EU Global', '', '', '', '', ''),
    ('Temu', 'Europe', '', '', '', '', ''),
    ('Shein', 'Europe', '', '', '', '', ''),
    ('TikTok Shop', 'Europe', '', '', '', '', ''),
    ('Independent Store', '-', '', '', '', '', ''),
]
for i, (plat, region, st, dt, res, reason, note) in enumerate(platforms, 2):
    ws2.cell(row=i, column=1, value=plat)
    ws2.cell(row=i, column=2, value=region)
    ws2.cell(row=i, column=3, value=st)
    ws2.cell(row=i, column=4, value=dt)
    ws2.cell(row=i, column=5, value=res)
    ws2.cell(row=i, column=6, value=reason)
    ws2.cell(row=i, column=7, value=note)
    for c in range(1, len(headers2)+1):
        style_data_cell(ws2, i, c)

widths2 = [14, 14, 18, 14, 14, 20, 25]
for w, col in zip(widths2, range(1, len(headers2)+1)):
    ws2.column_dimensions[get_column_letter(col)].width = w

# --- Sheet 3: Annual Declaration Reminders ---
ws3 = wb.create_sheet("Annual Reminders")
headers3 = ['Country', 'Declaration Cycle', 'Last Period', 'Next Deadline', 'Status',
            'Eco Fee Amount', 'Payment Status', 'Notes']
for c, h in enumerate(headers3, 1):
    ws3.cell(row=1, column=c, value=h)
style_header(ws3, 1, len(headers3))

reminder_data = [
    ('Germany', 'Annual', '2026', '', '', '', '', ''),
    ('France', 'Quarterly', '2026 Q2', '', '', '', '', ''),
    ('Italy', 'Annual', '2026', '', '', '', '', ''),
    ('Spain', 'Annual', '2026', '', '', '', '', ''),
    ('Belgium', 'Quarterly', '2026 Q2', '', '', '', '', ''),
    ('Netherlands', 'Annual', '2026', '', '', '', '', ''),
    ('Ireland', 'Annual', '2026', '', '', '', '', ''),
    ('Poland', 'Annual', '2026', '', '', '', '', ''),
    ('Sweden', 'Annual', '2026', '', '', '', '', ''),
]
for i, (country, cycle, period, dl, status, fee, pay, note) in enumerate(reminder_data, 2):
    ws3.cell(row=i, column=1, value=country)
    ws3.cell(row=i, column=2, value=cycle)
    ws3.cell(row=i, column=3, value=period)
    ws3.cell(row=i, column=4, value=dl)
    ws3.cell(row=i, column=5, value=status)
    ws3.cell(row=i, column=6, value=fee)
    ws3.cell(row=i, column=7, value=pay)
    ws3.cell(row=i, column=8, value=note)
    for c in range(1, len(headers3)+1):
        style_data_cell(ws3, i, c)

widths3 = [14, 12, 16, 16, 14, 18, 14, 25]
for w, col in zip(widths3, range(1, len(headers3)+1)):
    ws3.column_dimensions[get_column_letter(col)].width = w

tracker_path = os.path.join(base_dir, 'H_PPWR_合规进度追踪表.xlsx')
wb.save(tracker_path)
print(f"Tracker: {tracker_path} ({os.path.getsize(tracker_path)/1024:.1f} KB)")

# ============================================================
# 2. Flowchart Image (PNG)
# ============================================================
font_paths = ['C:/Windows/Fonts/msyh.ttc', 'C:/Windows/Fonts/simhei.ttf', 'C:/Windows/Fonts/NotoSansCJK-Regular.ttc']

def load_font(size):
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size)
            except:
                continue
    return ImageFont.load_default()

f12 = load_font(12)
f14 = load_font(14)
f16 = load_font(16)
f18 = load_font(18)
f20 = load_font(20)

W, H = 800, 1700
img = Image.new('RGB', (W, H), '#ffffff')
draw = ImageDraw.Draw(img)

def draw_box(x, y, w, h, text, font, fill='#EDF2F7', outline='#A0AEC0', text_color='#1A202C'):
    draw.rounded_rectangle([x, y, x+w, y+h], radius=8, fill=fill, outline=outline, width=1)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = x + (w-tw)//2
    ty = y + (h-th)//2
    draw.text((tx, ty), text, fill=text_color, font=font)

def draw_arrow(x1, y1, x2, y2, color='#A0AEC0'):
    draw.line([(x1, y1), (x2, y2)], fill=color, width=2)

# Title
draw.text((40, 20), "PPWR Compliance Flowchart", fill='#1A365D', font=f20)
draw.text((40, 52), "8 Steps from Start to Full Compliance", fill='#718096', font=f14)

# Steps
steps = [
    ("1. Confirm if product falls under PPWR scope", "#EBF8FF", "#4299E1"),
    ("2. Determine target countries (9-country list)", "#EBF8FF", "#4299E1"),
    ("3. Contact 3+ PROs for quotes (Appendix D)", "#FFFAF0", "#ED8936"),
    ("4. Submit registration + pay fees", "#F0FFF4", "#48BB78"),
    ("5. Receive EPR registration numbers", "#F0FFF4", "#48BB78"),
    ("6. Check packaging compliance (void ratio/hazards/labels)", "#FFFFF0", "#ECC94B"),
    ("7. Submit registration numbers to all platforms", "#F0FFF4", "#48BB78"),
    ("8. Set annual declaration reminders + update data", "#F7FAFC", "#A0AEC0"),
]

y = 90
for i, (text, fill, outline) in enumerate(steps):
    draw_box(100, y, 600, 48, text, f16, fill=fill, outline=outline)
    if i < len(steps) - 1:
        draw_arrow(400, y+48, 400, y+62)
        y += 62
    else:
        y += 55

# Online version box
y += 10
draw.rounded_rectangle([100, y, 700, y+80], radius=10, fill='#EBF8FF', outline='#4299E1', width=2)
draw.text((130, y+15), "Online Version (Continuous Updates)", fill='#1A365D', font=f18)
draw.text((130, y+42), "Policy changes -> Document updates instantly -> Users scan QR for latest version", fill='#4A5568', font=f14)

# Appendix mapping
y += 110
draw.text((40, y), "Appendix Tools Mapping", fill='#1A365D', font=f18)
y += 30

tools_map = [
    ("Appendix A", "Scope Checklist", "Step 1"),
    ("Appendix B", "9-Country EPR Table", "Steps 2-3"),
    ("Appendix C", "Registration Prep Checklist", "Step 3"),
    ("Appendix D", "Inquiry Email Template", "Step 3"),
    ("Appendix E", "Packaging Compliance Check", "Step 6"),
    ("Appendix F", "Multi-Platform Rules Comparison", "Step 7"),
    ("Appendix G", "10-Day Timeline", "All Steps"),
    ("Appendix H", "Progress Tracker (Excel)", "Full Process"),
    ("Appendix I", "Flowchart (PNG)", "Full Process"),
]

for tool, desc, step in tools_map:
    draw.rounded_rectangle([100, y, 700, y+28], radius=6, fill='#F7FAFC', outline='#E2E8F0')
    draw.text((120, y+4), f"{tool}: {desc} -> {step}", fill='#2D3748', font=f14)
    y += 33

# Footer
draw.rounded_rectangle([40, H-60, W-40, H-10], radius=8, fill='#1A365D')
draw.text((60, H-48), "heguimao.pages.dev | Online version continuously updated | Instant policy change sync", fill='#FFFFFF', font=f12)

flowchart_path = os.path.join(base_dir, 'I_PPWR_合规全流程图.png')
img.save(flowchart_path, 'PNG')
print(f"Flowchart: {flowchart_path} ({os.path.getsize(flowchart_path)/1024:.1f} KB)")

# ============================================================
# 3. Update ZIP
# ============================================================
import zipfile
main_dir = base_dir.replace('\\bonus', '')
zip_path = os.path.join(main_dir, 'PPWR_合规实操手册_中文版_附录包.zip')
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for item in os.listdir(base_dir):
        item_path = os.path.join(base_dir, item)
        if os.path.isfile(item_path):
            zf.write(item_path, item)

print(f"ZIP updated: {zip_path} ({os.path.getsize(zip_path)/1024:.1f} KB)")
