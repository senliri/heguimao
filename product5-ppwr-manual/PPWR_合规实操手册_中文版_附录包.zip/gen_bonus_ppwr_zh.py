# -*- coding: utf-8 -*-
"""
Generate Chinese PDFs for PPWR Bonus Tools (A-G)
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

base_dir = r'D:\qclaw\workspace-AI工程师\product5-ppwr-manual'
bonus_dir = os.path.join(base_dir, 'bonus')

# Register font
font_name = None
for fp, rn in [
    ('C:/Windows/Fonts/msyh.ttc', 'NotoSansSC'),
    ('C:/Windows/Fonts/simhei.ttf', 'SimHei'),
]:
    try:
        pdfmetrics.registerFont(TTFont(rn, fp))
        font_name = rn
        break
    except:
        pass

if not font_name:
    font_name = 'Helvetica'

styles = getSampleStyleSheet()

def make_style(name, parent='Normal', **kw):
    s = ParagraphStyle(name, parent=styles[parent], **kw)
    styles.add(s)
    return s

S_TITLE = make_style('S_TITLE', 'Heading1', fontSize=16, leading=20, spaceAfter=8, fontName=font_name, textColor=colors.HexColor('#1a365d'))
S_H1 = make_style('S_H1', 'Heading1', fontSize=13, leading=17, spaceBefore=12, spaceAfter=5, fontName=font_name, textColor=colors.HexColor('#2d3748'))
S_H2 = make_style('S_H2', 'Heading2', fontSize=11.5, leading=15, spaceBefore=8, spaceAfter=4, fontName=font_name, textColor=colors.HexColor('#4a5568'))
S_BODY = make_style('S_BODY', 'Normal', fontSize=10, leading=14, spaceAfter=3, fontName=font_name)
S_BLOCKQUOTE = make_style('S_BLOCKQUOTE', 'Normal', fontSize=9.5, leading=13, fontName=font_name, textColor=colors.HexColor('#4a5568'), leftIndent=10, backColor=colors.HexColor('#f7fafc'), borderPadding=5)
S_TABLE_H = make_style('S_TABLE_H', 'Normal', fontSize=9, leading=11, fontName=font_name, textColor=colors.white, alignment=1)
S_TABLE_C = make_style('S_TABLE_C', 'Normal', fontSize=9, leading=11, fontName=font_name)
S_FOOTER = make_style('S_FOOTER', 'Normal', fontSize=8, leading=10, fontName=font_name, textColor=colors.HexColor('#a0aec0'), alignment=1)

import re

def parse_checkbox(text):
    text = re.sub(r'\[ \]', '☐', text)
    text = re.sub(r'\[x\]', '☑', text)
    text = re.sub(r'\[X\]', '☑', text)
    return text

def md_to_flowables(lines, is_bonus=False):
    elements = []
    in_table = False
    table_data = []
    table_headers = []
    in_blockquote = False
    bq_lines = []
    
    def flush_table():
        nonlocal in_table, table_data, table_headers
        if table_data:
            if table_headers:
                header_row = [Paragraph(c.strip(), S_TABLE_H) for c in table_headers]
                table_data.insert(0, header_row)
            t = Table(table_data, repeatRows=1)
            cmds = [
                ('BACKGROUND', (0,0), (-1,-1), colors.white),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#e2e8f0')),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('LEFTPADDING', (0,0), (-1,-1), 4),
                ('RIGHTPADDING', (0,0), (-1,-1), 4),
                ('TOPPADDING', (0,0), (-1,-1), 3),
                ('BOTTOMPADDING', (0,0), (-1,-1), 3),
            ]
            if table_headers:
                cmds.insert(0, ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a365d')))
                cmds.insert(0, ('TEXTCOLOR', (0,0), (-1,0), colors.white))
            t.setStyle(TableStyle(cmds))
            elements.append(t)
        in_table = False
        table_data = []
        table_headers = []
    
    def flush_bq():
        nonlocal in_blockquote, bq_lines
        if bq_lines:
            elements.append(Paragraph(parse_checkbox('\n'.join(bq_lines)), S_BLOCKQUOTE))
        in_blockquote = False
        bq_lines = []
    
    for line in lines:
        raw = line.rstrip('\n\r')
        
        if raw.strip() == '':
            flush_bq()
            flush_table()
            continue
        
        if raw.startswith('---'):
            flush_bq()
            flush_table()
            elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#e2e8f0'), spaceBefore=6, spaceAfter=6))
            continue
        
        if raw.startswith('> '):
            flush_table()
            in_blockquote = True
            bq_lines.append(raw[2:])
            continue
        
        if raw.strip().startswith('|'):
            flush_bq()
            cells = [c.strip() for c in raw.split('|')[1:-1]]
            if all(c == '-' * len(c) for c in cells):
                continue
            if not table_headers:
                table_headers = cells
            table_data.append([Paragraph(parse_checkbox(c), S_TABLE_C) for c in cells])
            in_table = True
            continue
        
        m = re.match(r'^#\s+(.*)', raw)
        if m:
            flush_bq()
            flush_table()
            elements.append(Paragraph(parse_checkbox(m.group(1)), S_TITLE))
            continue
        
        m = re.match(r'^##\s+(.*)', raw)
        if m:
            flush_bq()
            flush_table()
            elements.append(Paragraph(parse_checkbox(m.group(1)), S_H1))
            continue
        
        m = re.match(r'^###\s+(.*)', raw)
        if m:
            flush_bq()
            flush_table()
            elements.append(Paragraph(parse_checkbox(m.group(1)), S_H2))
            continue
        
        flush_bq()
        flush_table()
        text = parse_checkbox(raw)
        text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
        elements.append(Paragraph(text, S_BODY))
    
    flush_bq()
    flush_table()
    return elements

# Process each bonus file
bonus_files = sorted([f for f in os.listdir(bonus_dir) if f.endswith('.md') and '_zh.md' in f])

for fname in bonus_files:
    md_path = os.path.join(bonus_dir, fname)
    pdf_name = fname.replace('.md', '.pdf')
    pdf_path = os.path.join(bonus_dir, pdf_name)
    
    print(f"Processing: {fname}")
    with open(md_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    doc = SimpleDocTemplate(
        pdf_path, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )
    
    flowables = md_to_flowables(lines)
    doc.build(flowables)
    
    fsize = os.path.getsize(pdf_path)
    print(f"  -> {pdf_name} ({fsize/1024:.1f} KB)")

print("\nAll bonus PDFs generated!")
