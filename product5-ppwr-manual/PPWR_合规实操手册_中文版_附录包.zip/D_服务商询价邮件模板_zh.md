# D. 服务商询价邮件模板

> 直接复制发给 PRO/合规服务商
> 适用：需要联系各国 PRO 询价的卖家

---

## 模板 1：英文通用版（推荐）

```
Subject: Inquiry for Packaging EPR Registration - [Your Company Name]

Dear [PRO Name / Service Provider],

I am writing to inquire about packaging EPR registration services for our company exporting to the [Country Name] market.

Company Information:
- Company Name: [Your Company Name]
- Website: [Your Website]
- Contact Person: [Your Name]
- Email: [Your Email]

Product Information:
- Product Category: [e.g., Consumer Electronics / Home Goods / Clothing]
- Packaging Type(s): [e.g., Cardboard boxes, Plastic bags, Bubble mailers]
- Estimated Annual Packaging Weight: [e.g., 2,000 kg]
- Estimated Annual Shipments to [Country]: [e.g., 50,000 packages]

Services Required:
1. EPR packaging registration
2. Annual reporting assistance
3. Eco-contribution fee payment (if applicable)

Please provide:
1. Registration fee
2. Estimated annual eco-contribution fee based on the above data
3. Processing time for registration
4. Required documents
5. Annual renewal process and fees
6. Whether you offer Chinese-speaking support

We are looking to register ASAP as the PPWR deadline is August 12, 2026.

Looking forward to your response.

Best regards,
[Your Name]
[Your Title]
[Your Company Name]
[Phone Number with Country Code]
```

---

## 模板 2：中文版（发给中文服务商）

```
主题：[国家名称] 包装法 EPR 注册咨询 - [你的公司名]

您好，

我司计划向 [国家名称] 市场出口产品，需要了解包装法 EPR 注册服务。

公司信息：
- 公司名称：[你的公司名]
- 网站：[你的网站]
- 联系人：[你的姓名]
- 邮箱：[你的邮箱]

产品信息：
- 产品品类：[如消费电子/家居用品/服装]
- 包装类型：[如纸箱/塑料袋/气泡袋]
- 预计年包装重量：[如 2000 公斤]
- 预计年发往 [国家] 数量：[如 5 万件]

所需服务：
1. EPR 包装注册
2. 年度申报协助
3. 生态贡献费代缴（如适用）

请提供：
1. 注册费用
2. 基于上述数据的预估年生态贡献费
3. 注册所需时间
4. 所需材料清单
5. 年度续费流程和费用
6. 是否提供中文支持

PPWR 截止日期为 2026 年 8 月 12 日，我们希望尽快完成注册。

盼复。

此致
[你的姓名]
[你的职位]
[你的公司名]
[电话（含国际区号）]
```

---

## 模板 3：追加咨询（已收到报价后）

```
Subject: Follow-up Questions Regarding EPR Registration Quote

Dear [Name],

Thank you for the quotation. I have a few follow-up questions:

1. Does the fee cover all packaging categories (sales, group, shipping)?
2. What happens if our packaging weight increases by 50% mid-year?
3. Do you handle the platform registration submission as well?
4. What is the penalty if we miss the annual reporting deadline?
5. Can you provide a reference case of a Chinese seller you've helped?

Looking forward to your reply.

Best regards,
[Your Name]
```

---

## 询价建议

1. **至少联系 3 家 PRO** 进行比较
2. **重点关注**：注册周期、是否支持中文、年费透明度
3. **警惕低价陷阱**：过低报价可能隐藏后续费用
4. **确认服务范围**：是否包含年度申报、平台提交协助
5. **保留书面记录**：所有沟通和报价都要有邮件确认

---

> 本模板基于各国 PRO 标准询价流程整理。
> 可根据实际情况调整内容。
